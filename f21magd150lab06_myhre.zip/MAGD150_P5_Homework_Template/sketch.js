var open  = 0;
var x2 = 800;
var pacmovex = 200;
var speed = 1.25;
var speed2 = -1.25;
var y1 = 0
function setup() {
  createCanvas(800, 800);
}

function draw() {
  background(0);
  pac(pacmovex,400);
  xpip();
  openfunct();
  if (pacmovex > 625){
    speed = -1.25;
  }else if (pacmovex < 100){
    speed = 1.25;
  }
  pacmovex = pacmovex + speed;
  
  if (x2 < 25){
    speed2 = 1.25;
  }else if (x2 > 775){
    speed2 = -1.25;
  }
  x2 = x2 + speed2;
  pip2();
}




function xpip(){
  //this creates the pips that are moving on the x cordinate plane, that are bouncing along with pac man.
  fill(255);
  noStroke();
  rect(x2,200,25,25);
  rect(x2,600,25,25);
  scale(2.0);
  rect(x2,50,25,25);
  rect(x2,350,25,25);

  
  
  

}
function pac(x,y){
  //what this function does is it creates the two different states of the pac man in the center of the screen.
  stroke(0);
  fill(250,248,0);
  if (open <= 45 ) {
    beginShape();
    vertex(x,y);
    vertex(x+50,y);
    vertex(x+50,y-25);
    vertex(x+125,y-25);
    vertex(x+125,y-50);
    vertex(x+175,y-50);
    vertex(x+175,y-100);
    vertex(x+150,y-100);
    vertex(x+150,y-125);
    vertex(x+100,y-125);
    vertex(x+100,y-150);
    vertex(x-25,y-150);
    vertex(x-25,y-125);
    vertex(x-25,y-100);
    vertex(x-75,y-100);
    vertex(x-75,y-50);
    vertex(x-100,y-50);
    vertex(x-100,y+75);
    vertex(x-75,y+75);
    vertex(x-75,y+125);
    vertex(x-50,y+125);
    vertex(x-50,y+150);
    vertex(x,y+150);
    vertex(x,y+175);
    vertex(x+125,y+175);
    vertex(x+125,y+150);
    vertex(x+175,y+150);
    vertex(x+175,y+100);
    vertex(x+125,y+100);
    vertex(x+125,y+75);
    vertex(x+125,y+50);
    vertex(x+75,y+50);
    vertex(x+75,y+25);
    vertex(x,y+25);
    vertex(x,y)
    endShape();
  }else if (open >= 45 ) {
    beginShape();
    vertex(x+200,y);
    vertex(x+200,y);
    vertex(x+200,y-25);
    vertex(x+200,y-25);
    vertex(x+200,y-50);
    vertex(x+175,y-50);
    vertex(x+175,y-100);
    vertex(x+150,y-100);
    vertex(x+150,y-125);
    vertex(x+100,y-125);
    vertex(x+100,y-150);
    vertex(x-25,y-150);
    vertex(x-25,y-125);
    vertex(x-25,y-100);
    vertex(x-75,y-100);
    vertex(x-75,y-50);
    vertex(x-100,y-50);
    vertex(x-100,y+75);
    vertex(x-75,y+75);
    vertex(x-75,y+125);
    vertex(x-50,y+125);
    vertex(x-50,y+150);
    vertex(x,y+150);
    vertex(x,y+175);
    vertex(x+125,y+175);
    vertex(x+125,y+150);
    vertex(x+175,y+150);
    vertex(x+175,y+100);
    vertex(x+200,y+100);
    vertex(x+200,y+75);
    vertex(x+200,y+50);
    vertex(x+200,y+50);
    vertex(x+200,y+25);
    vertex(x+200,y+25);
    vertex(x+200,y)
    endShape();
  }
}

function openfunct(){
  //this function is the function that helps do the pac man open mouth animation thing, it sets the open value to a state of adding +1 every time until it reaches a certain amount at which it resets the number to 0.
  if (open <= 100 ){
   open = open + 1;
  }else if (open >= 100){
    open = 0;
  }
}

function pip2(){
  //what this function does is it makes a pip that is rotated 50 degrees and out 100 on the x cordinate plane shifted by 50 degrees.
  angleMode(DEGREES);
  rotate(50);
  translate(100,0);
  rect(0,0,25,25);
}