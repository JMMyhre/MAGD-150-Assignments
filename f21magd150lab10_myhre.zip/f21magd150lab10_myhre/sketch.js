let angle = 0;
let image;
let tabled;

function preload(){
tabled = loadTable("this.csv");
}


function setup() {
  createCanvas(500, 500, WEBGL);
  image = loadImage('map.JPG');

  let ahh = tabled.get(1,2);
  print(ahh);
}



function draw() {
  camera(0,0,200+mouseX,0,0,0,0,1,0);
  directionalLight(255, 255, 255, 0, 0, -1);
  directionalLight(255, 255, 255, 0, 1, 0);
  let lX = mouseX - width / 2;
  let lY = mouseY - height / 2;
  pointLight(250, 250, 250, lX, lY, 50);
  background(200);
  push();
  rotateX(angle);
  texture(image);
  noStroke();
  plane(150);
  angle += 0.05;
  pop();
  push();
  translate(-200,0,-100);
  specularMaterial(250);
  shininess(50);
  box(100,500,100);
  pop();
  push();
  translate(200,0,-100);
  specularMaterial(250);
  shininess(50);
  box(100,500,100);
  pop();
  push();
  translate(100,0,-200);
  specularMaterial(250);
  shininess(50);
  box(100,500,100);
  pop();
  push();
  translate(-100,0,-200);
  specularMaterial(250);
  shininess(50);
  box(100,500,100);
  pop();
  push();
  translate(0,0,-300);
  specularMaterial(250);
  shininess(50);
  box(100,500,100);
  pop();
  textSize(100)
  textAlign(CENTER,CENTER);

}