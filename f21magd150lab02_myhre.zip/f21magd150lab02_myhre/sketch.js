function setup() {
  createCanvas(800, 800);
  background(50);
}

function draw() {
  colorMode(RGB);
  let a = color(245,100,10);
  fill(a);
  noStroke();
  ellipse(400,400,400,400, [CENTER]);
  
  colorMode(HSB,360,100,100,100);
  noFill();
  stroke(23,66,97);
  strokeWeight(25);
  bezier(240,300,600,350,100,450,585,450);
  bezier(210,400,500,430,40,550,525,540);
  bezier(320,220,675,270,200,375,585,350);

  
  colorMode(RGB);
  let b = color('#C24F08');
  stroke(b);
  line(600,200,200,600);
  
  let c = color('#787061');
  stroke(c);
  fill(c);
  beginShape();
  vertex(0,600);
  vertex(75,600);
  vertex(150,650);
  vertex(550,650);
  vertex(625,550);
  vertex(800,550);
  vertex(800,800);
  vertex(0,800);
  endShape();
  
  let d = color('#FFFFFF');
  stroke(d);
  fill(d);
  triangle(650,100,660,100,655,110);
  triangle(650,105,660,105,655,95);
  triangle(150,100,160,100,155,110);
  triangle(150,105,160,105,155,95);
  strokeWeight(10);
  point(400,100)
  point(300,100)
  point(500,100)
  point(500,200)
  point(300,200)
  point(100,100)
  point(700,100)
  point(100,200)
  point(700,200)
  point(100,300)
  point(700,300)
  point(100,400)
  point(700,400)
  point(100,500)
  point(700,500)
  point(200,100)
  point(600,100)
  point(200,200)

  
}