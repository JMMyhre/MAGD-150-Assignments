let x = 0;
let x2 = -400;
let y = -800;
let mouse = 0;
let speed = 2;
let key1 = 0;
let i = 0;
function setup() {
  createCanvas(800, 800);
}
function draw() {
  background(255);
  if(key1 == 1){
    background(157,255,146);
  }
  if(key1 == 2){ 
    background(194,221,255);
  }
  if(key1 == 3){
    background(255,151,255);
  }
  if(key1 == 4){
    key1 = 0;
  }
  if(x == 400){
    x = 400;
  }
  else{
    x = x + speed
  }
  if(x2 == 400){
    x2 = 400;
  }
  else{
    x2 = x2 + speed
  }
  if(y == 400){
    y = 400;
  }
  else{
    y = y + speed
  }
  fill(163,90,21);
  noStroke();
  triangle(x-200,500,x,200,x+200,400);
  fill(255,44,36);
  noStroke();
  triangle(x2-200,500,x2-20,230,x2+170,408);
  fill(255,238,94);
  noStroke();
  triangle(200,y+100,370,y-157,550,y+15);
  if(mouse == 1){
    fill(255,0,0);
    ellipse(300,425,75,75);
    ellipse(430,400,75,75);
    ellipse(370,330,75,75);
    ellipse(mouseX,mouseY,75,75);
  }
  if(mouse == 2){
    fill(117,65,18);
    ellipse(300,425,30,30);
    ellipse(430,400,30,30);
    ellipse(370,330,30,30);
    ellipse(360,380,30,30);
    ellipse(375,420,30,30);
    ellipse(250,470,30,30);
    ellipse(500,400,30,30);
    ellipse(440,350,30,30);
    ellipse(370,293,30,30);
    ellipse(310,370,30,30);
    ellipse(mouseX,mouseY,30,30);
  }
  if(mouse == 3){
    mouse = 0;
  }
  i++
}  
function mousePressed(){
  if (mouseIsPressed){
    mouse = mouse + 1;
  }
}
function keyPressed(){
  if(keyIsPressed){
    key1 = key1 + 1;
  }
}
for(let i = 0; i<100; i++){
  ellipse(mouseX,mouseY,100,100);
}
